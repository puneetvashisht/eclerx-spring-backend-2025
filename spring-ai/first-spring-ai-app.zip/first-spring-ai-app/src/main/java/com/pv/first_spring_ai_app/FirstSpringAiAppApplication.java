package com.pv.first_spring_ai_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringAiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringAiAppApplication.class, args);
	}

}
