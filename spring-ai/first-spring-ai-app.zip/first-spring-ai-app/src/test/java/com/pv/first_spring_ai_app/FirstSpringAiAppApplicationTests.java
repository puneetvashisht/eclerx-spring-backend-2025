package com.pv.first_spring_ai_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringAiAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
