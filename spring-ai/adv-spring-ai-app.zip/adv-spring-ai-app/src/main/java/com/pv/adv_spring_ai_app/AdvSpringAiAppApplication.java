package com.pv.adv_spring_ai_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvSpringAiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvSpringAiAppApplication.class, args);
	}

}
